#!/bin/bash

if [ "$1" == "stop" ]; then
    # docker rm -f $(sudo docker ps -a -q)
    docker-compose kill
    exit 0
fi

if [ "$1" == "restart" ]; then
    # docker rm -f $(sudo docker ps -a -q)
    docker-compose kill
fi

docker-compose up -d --remove-orphans

# shows api logs
if [ "$1" == "logs" ]; then
    docker-compose logs -f
fi
